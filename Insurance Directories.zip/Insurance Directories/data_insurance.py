import requests
from bs4 import BeautifulSoup
import re

to0 = open("links.csv", "r")
df = to0.readlines()
global i
i = 1819
while(i<=3027):
    url = "http://www.insurance-directories.com"+str(df[i].replace("\n",""))
    data = requests.get(url)
    soup = BeautifulSoup(data.text, "html.parser")
    try:
        policy = str(soup.find("div", {"class": "single-col policies col-md-6 col-sm-12"}).get_text())
    except:
        try:
            policy = str(soup.find("div", {"class": "single-col products-services col-md-6 col-sm-12"}).get_text())
        except:
            print("none")
    name = str(soup.find("h2", {"class": "companyname"}).get_text())
    filename = re.sub('[^A-Za-z0-9 ]+', '', name)
    data = str(soup.find("div", {"class": "contact-details shaded"}))
    soup1 = BeautifulSoup(data, "html.parser")
    data = soup.findAll("p")
    to = open(str(filename)+".txt","w")
    to.write("Name : " + name+"\n\n")
    to.write("Address : " + str(data[0].text)+"\n")
    to.write(str(data[1].text).replace("\r\n", "\n").replace("                        ","")+"\n")
    to.write("Key Personal : " + str(data[3].text).replace("                        ", ""))
    to.write(policy.replace("                                            ","    ").replace("\n\n\n\r\n","\n"))
    to.close()

    i+=1
    print(i)
