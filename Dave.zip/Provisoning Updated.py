# This file supports the current Fiverr project
import os
import requests
from bs4 import BeautifulSoup
import re
from platform import python_version
import json
from urllib import request

RETRIEVAL_SUCCESS = 204


def retrieve_webpage_at_url(url):  # DONE
    """
    Retrieves a webpage's content and a return code for the webpage at the URL
    :param url: (string) URL from which to retrieve the webpage
    :return: (tuple of int,string) return code, content
    """

    code = requests.get(url)

    #print("NOT IMPLEMENTED YET - need a function for returning a webpage and its return code for a URL")

    return RETRIEVAL_SUCCESS, code


def execute_pip_command(name,command):  # DONE
    """
    Executes the provided pip command within a virtual environent
    :param command: (string) pip command to execute
    :return: (empty)
    """
    #this will execute the pip command

    os.chdir(name+'\Scripts')

    os.system("activate.bat")
    os.system(command)
    #print("NOT IMPLEMENTED YET - need function for executing PIP command within venv")


class Provisioning:

    def __init__(self):
        """
        Merely initializes data structures
        """

        self.set_software_instance(None)

    def set_software_instance(self, software_instance):
        """
        Simple setter for Software instance
        :param software_instance: (Software) instance of Software class
        :return: (empty)
        """

        self.software_instance = software_instance

    def get_software_instance(self):
        """
        Simple getter for Software instance
        :return: (Software) instance of Software class
        """

        return self.software_instance


class Software:

    def __init__(self):
        """
        Merely initializes data structures
        """

        self.set_python_instance(None)
        self.set_django_instance(None)
        self.set_venv_instance(None)
        self.set_packages_instance(None)

    def set_python_instance(self, python_instance):
        """
        Simple setter for Python instance
        :param python_instance: (Python) instance of Python class
        :return: (empty)
        """

        self.python_instance = python_instance

    def get_python_instance(self):
        """
        Simple getter for Python instance
        :return: (Python) instance of Python class
        """

        return self.python_instance

    def set_django_instance(self, django_instance):
        """
        Simple setter for Django instance
        :param django_instance: (Django) instance of Django class
        :return: (empty)
        """

        self.django_instance = django_instance

    def get_django_instance(self):
        """
        Simple getter for Django instance
        :return: (Django) instance of Django class
        """

        return self.django_instance

    def set_venv_instance(self, venv_instance):
        """
        Simple setter for Venv instance
        :param venv_instance: (Venv) instance of Venv class
        :return: (empty)
        """

        self.venv_instance = venv_instance

    def get_venv_instance(self):
        """
        Simple getter for Venv instance
        :return: (Venv) instance of Venv class
        """

        return self.venv_instance

    def set_packages_instance(self, packages_instance):
        """
        Simple setter for Packages instance
        :param packages_instance: (Packages) instance of Packages class
        :return: (empty)
        """

        self.packages_instance = packages_instance

    def get_packages_instance(self):
        """
        Simple getter for Packages instance
        :return: (Packages) instance of Packages class
        """

        return self.packages_instance


class Python:
    LATEST = "latest"
    PYTHONORG_DOWNLOADS_URL = "https://www.python.org/downloads/"

    def __init__(self, version=None):  # DONE
        """
        Merely initializes data structures
        """

        self.set_version(version)

    def set_version(self, version):  # DONE
        """
        Simple setter for version
        :param version: (string) software version
        :return: (empty)
        """

        self.version = version

    def get_version(self):  # DONE
        """
        Simple getter for version
        :return: (string) software version
        """

        return self.version

    def set_package_version_latest(self):
        """
        Sets version to LATEST
        :return: (empty)
        """
        self.set_version(self.LATEST)

    def parse_python_webpage_for_versions(self, webpage):  # DONE
        """
        Parses Python versions from a HTML webpage
        :param webpage: (string) HTML webpage
        :return: (list of strings) package versions; e.g.; ["2.4.4", "2.5.1"]
        """


        url = "https://www.python.org/doc/versions/"
        source_code = requests.get(url)
        plain_text = source_code.text
        soup = BeautifulSoup(plain_text, "html.parser")

        # find_text = soup.findAll("div", id="python-documentation-by-version", )
        find_text = soup.find_all("a", {"class": "reference external"})
        python_versions = []
        try:

            for string in find_text:
                version = re.findall(r'[0-9]+', str(string))
                single = version[0] + "." + version[1] + "." + version[2]
                python_versions.append(single)
        except:
            pass
        #print("NOT IMPLEMENTED - need a function for parsing webpage for Python versions")


        return python_versions

    def identify_url_for_python_versions(self):
        """
        Generates a URL string for retrieving Python versions
        :return: (string) URL on Python.org
        """

        return self.PYTHONORG_DOWNLOADS_URL

    def retrieve_webpage_at_url(self, url):
        """
        Retrieves the provided URL and returns the return code and content
        :param url: (string) url of the webpage to retrieve
        :return: (int, string) return value and content of page
        """

        # Simple pass-through
        return retrieve_webpage_at_url(url)


def is_latest_version_requested(self):  # DONE
    """
    Returns True if latest was requested; returns False otherwise
    :return: (bool) True if latest was requested
    """
    if self.get_version() == self.LATEST:
        return True
    return False


def retrieve_python_versions(self):
    """
    Retrieves the valid Python versions as a list of strings and returns
    the Python versions from newest version to oldest version
    :return: (list of strings)
    """

    # Generate a URL for retrieving Python versions
    # from Python.org

    url_for_python_versions = self.identify_url_for_python_versions()

    # Retrieve webpage and return status for that URL
    return_code, webpage = self.retrieve_webpage_at_url(url_for_python_versions)

    return self.parse_python_webpage_for_versions(webpage)


def validate_python_version(self):  # DONE
    """
    Validates that the requested version is one of the versions listed on
    python.org
    :return: (empty)
    """

    # Return early if LATEST is selected since a LATEST will exist
    if self.is_latest_version_requested():
        return

    requested_version = self.get_version()

    # Error early if requested version is 2.X
    if requested_version.startswith("2"):
        raise (
        Exception, "Error: requested Python version (%s) is a 2.X version that is not supported" % requested_version)

    # LATEST version was not requested so validate requested version
    python_versions = self.retrieve_python_versions()

    if not requested_version in python_versions:
        raise (Exception, "Error: requested version (%s) of Python is not available on Python.org" % requested_version)


def install_python(self):  # This is done in the method of creating venv
    """
    Installs the requested version of Python within
    the virtual environment
    :return: (empty)
    """
    # Validate Python version prior to attempting installation
    self.validate_python_version()

    # form a command for installing Python
    if self.is_latest_version_requested():
        command = "FIRST COMMAND"
    else:
        command = "SECOND COMMAND %s" % self.get_version()

    # execute the command within the virtual environment
    print("Not implemented yet - need code to execute Python installation command within virtual environment")


class Venv:

    def __init__(self, location=None):
        """
        Merely initializes data structures
        """

        self.set_location(None)

    def set_location(self, location):
        """
        Simple setter for location
        :param location: (string) directory path to venv installation
        :return: (empty)
        """

        self.location = location

    def get_location(self):
        """
        Simple getter for location
        :return: (string) directory path to venv installation
        """

        return self.location

    def validate_python_version(self):  # DONE
        """
        Validates that installed Python version is 3.3+
        so that "venv" feature is available
        :return: (empty)
        """


        version_values = python_version().split(".")
        if (int(version_values[0]) == 3 and int(version_values[1]) >= 3):
            print("Python Version is 3.3+")
        else:
            print("Python Version is below 3.3")
            exit()

        #print("NOT IMPLEMENTED - must add code to validate executing Python version as 3.3+")

    def validate_venv_location(self, location):  # DONE
        """
        Validates that the provided directory path
        exists or create it if possible
        :return: (empty)
        """


        if(os.path.isdir(location)):
            pass
        else:
            # print("NOT DONE - insert code here for splitting directory path into subdirectory components")
            try:
                os.makedirs(location)
            except FileExistsError:
                # directory already exists
                pass

        # Split location by directory path separators
        # taking into account that Windows and Linux use
        # different separators

        # Iterate through subdirectory components ensuring
        # that each component exists or create it
        #print("NOT DONE - insert code here for confirming existence of each subdirectory component or creating it")

    def install_venv_at_location(self,location,path_of_the_python_file,name_of_the_venv):  # DONE
        """
        Installs a virtual environment (through "python -m venv" or similar)
        at the provided location
        :return:
        """
        # Validate existence of provided directory path
        # and create subdirectories if needed
        self.validate_venv_location(location)

        location = self.get_location()  # location where venv will be installed
        os.chdir(location)
        #command to create virtual enviourment in the loction specified with the python version specified
        os.system("virtualenv --python=" + path_of_the_python_file + " " + name_of_the_venv)

        # Ensure that venv capability is available
        self.validate_python_version()


       # print("Not implemented yet - need to create and execute a command for installing a particular Python version within a virtual environment at a particular location")


class Packages:

    def __init__(self):
        """
        Merely initializes data structures
        """

        self.set_packages([])

    def set_packages(self, packages):
        """
        Simple setter for list of Package instances
        :param packages: (list of Package instances)
        :return: (empty)
        """

        self.packages = packages

    def get_packages(self):
        """
        Simply returns the list of Package instances
        :return: (list of Package instances) packages
        """
        return self.packages

    def add_package_to_packages(self, package=None):
        """
        Adds a single Package instance to Packages
        :param package: (Package) package to add
        :return: (empty)
        """

        # Add Package instance to end of packages list
        self.get_packages().append(package)

    def install_packages(self,name):
        """
        Iteratively installs packages
        :return: (empty)
        """
        packages = self.get_packages()

        for package in packages:
            package.install_package(name)


class Package:
    LATEST = "latest"
    RETRIEVAL_SUCCESS = 204

    def __init__(self, name=None, version=None):
        """
        Merely stores initial values
        """
        self.set_name(name)
        self.set_version(version)

    def set_name(self, name=None):
        """
        Simple setter for package name
        :param name: (string) package name
        :return: (empty)
        """

        if name is None:
            raise (Exception, "Error: package name cannot be None")

        self.name = name

    def get_name(self):
        """
        Simple getter for package name
        :return: (string) package name
        """
        return self.name

    def set_version(self, version=None):
        """
        Simple setter for package version
        :param version: (string) package version
        :return: (empty)
        """

        if version is None:
            raise (Exception, "Error: package version cannot be None")

        self.version = version

    def get_version(self):
        """
        Simple getter for package version
        :return: (string) package version
        """
        return self.version

    def set_version_latest(self):
        """
        Sets package version to LATEST
        :return: (empty)
        """
        self.set_version(self.LATEST)

    def is_latest_version_requested(self):  # DONE
        """
        Returns True if latest was requested; returns False otherwise
        :return: (bool) True if latest was requested
        """

        if (self.version == self.LATEST):
            return True
        return False

    def identify_pypi_url_for_package_versions(self):
        """
        Generates a URL string from package name
        :return: (string) URL on pypi.org
        """

        return "https://pypi.org/project/%s/#history" % self.get_name()

    def retrieve_webpage_at_url(self, url):  # DONE
        """
        Retrieves the provided URL and returns the return code and content
        :param url: (string) url of the webpage to retrieve
        :return: (int, string) return value and content of page
        """

        return retrieve_webpage_at_url(url)  # Simple pass-through

    def parse_package_versions_from_webpage(self, package_name):  # DONE

        """
        Parses package versions from a HTML webpage
        :param webpage: (string) HTML webpage
        :return: (list of strings) package versions; e.g.; ["2.4.4", "2.5.1"]
        """

        url = "https://pypi.org/pypi/%s/json" % (package_name,)
        data = json.load(request.urlopen(request.Request(url)))
        versions = data["releases"].keys()
        return versions

        #print("NOT IMPLEMENTED YET - need a method for parsing package versions from HTML webpage")

    def retrieve_package_versions(self,package_name):  # DONE
        """
        Retrieves valid package versions from Pypi in order from most
        recent to oldest (i.e., in the order that Pypi lists the versions)
        :return: (list of strings) valid package versions
        """

        # Generate a URL for retrieving package versions from Pypi
        url_for_package_versions = self.identify_pypi_url_for_package_versions()

        # Retrieve webpage and return status for that URL
        return_code, webpage = self.retrieve_webpage_at_url(url_for_package_versions)

        return self.parse_package_versions_from_webpage(package_name)

    def identify_pypi_url_for_package(self):  # DONE
        """
        Generates a URL string from package name
        :return: (string) URL on pypi.org
        """

        return "https://pypi.org/project/%s" % self.get_name()

    def validate_package_name(self):  # DONE
        """
        Uses a URL for the package to confirm that Pypi has a webpage
        for that package, thereby validating the package name
        :return: (empty)
        """
        url_for_package = self.identify_pypi_url_for_package()

        return_code, content = self.retrieve_webpage_at_url(url_for_package)

        if return_code != self.RETRIEVAL_SUCCESS:
            raise (Exception, "Error: package (%s) not found" % self.get_name())

    def validate_package_version(self):  # DONE
        """
        Validates that the requested version is one of the versions listed on
        Pypi for the requested package
        :return: (empty)
        """

        # If execution reaches this point, it has already validated the
        # package name so at least one version of the package exists.  Return
        # early if LATEST is selected since a LATEST will exist
        if self.is_latest_version_requested():
            return

        # LATEST version was not requested so validate requested version
        package_versions = self.retrieve_package_versions(self.get_name())
        requested_version = self.get_version()

        if not requested_version in package_versions:
            raise (Exception, "Error: requested version (%s) of package (%s) not listed on Pypi" % (requested_version,
                                                                                                    self.get_name()))

    def install_package(self,name_of_the_venv):  # DONE
        """
        Installs the requested package
        :return: (empty)
        """

        # Validate package name prior to attempting installation
        self.validate_package_name()

        # Validate package version prior to attempting installation
        self.validate_package_version()

        # form a command for installing the package
        command = "pip install " + self.get_name()

        # execute the command within the virtual environment
        execute_pip_command(name_of_the_venv,command)


class Django(Package):
    PACKAGE_NAME = "django"

    def __init__(self, package_version=None):
        """
        Merely stores initial values
        """
        super().__init__(name=self.PACKAGE_NAME, version=package_version)


def main():
    """
    Creates a class instance hierarchy and triggers parsing of it
    :return: (empty)
    """

    # Create Provisioning instance
    provisioning = Provisioning()

    # Create Software instance and store it within Provisioning instance
    software = Software()
    provisioning.set_software_instance(software)

    # Create Python, Django, Packages and Venv instances and store them
    # within Software instance
    python = Python("3.8")  # Python version 3.8
    software.set_python_instance(python)
    django = Django("3.0")  # Django version 3.1
    software.set_django_instance(django)
    venv = Venv("C:\\Users\\Dexter")
    venv.set_location("C:\\Users\\Dexter")
    software.set_venv_instance(venv)# venv at provided path

    #remeber to add the same python version file path here for which you want to create your venv for
    path_of_the_python_file = "C:\\Users\\Dexter\\AppData\\Local\\Programs\\Python\\Python37\\python.exe"
    name = str(input("Enter Virtual Enviourment Name : "))
    location = str(venv.location)
    packages = Packages()
    software.set_packages_instance(packages)

    # Add several packages - one with a particular version and one with latest
    package1 = Package(name="django-extensions", version="3.0.3")
    package2 = Package(name="django-crispy-forms", version="latest")
    packages.add_package_to_packages(package1)
    packages.add_package_to_packages(package2)

    pass  # Can set a breakpoint here to validate data structure creation

    # Now install the software
    venv.install_venv_at_location(location,path_of_the_python_file, name)  # Start by creating virtual environment
    # python.install_python_within_venv()  # Now install Python
    django.install_package(name)  # Now install Django
    packages.install_packages(location+"\\"+name)  # Now install all packages


# The commandline-executable portion of the code begins here

if __name__ == "__main__":
    main()
