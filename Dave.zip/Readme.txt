1. Install the requirements by "pip install -r requirements"
2. Run the python file 